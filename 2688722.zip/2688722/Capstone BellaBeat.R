install.packages('tidyverse')
library(ggplot2)
library(dplyr)
library(tidyverse)
library(readr)

daily_activity <- read.csv('dailyActivity_merged.csv')

is_null(daily_activity)

str(daily_activity)

Sum_Very_Active <- daily_activity %>% group_by(Id) %>%
  drop_na() %>%
  summarize(sum_very_active = sum(VeryActiveDistance))

Sum_Mod_Active <- daily_activity %>% group_by(Id) %>%
  drop_na() %>%
  summarize(sum_mod_active = sum(ModeratelyActiveDistance))

Sum_Light_Active <- daily_activity %>% group_by(Id) %>%
  drop_na() %>%
  summarize(sum_light_active = sum(LightActiveDistance))

Summary_Chart_temp <- merge(Sum_Very_Active, Sum_Mod_Active, by=("Id"))
Summary_Chart <- merge(Summary_Chart_temp, Sum_Light_Active, by="Id")
barplot_data <- Summary_Chart[c(-1)]
sumdata = data.frame(value=apply(barplot_data,2,sum))
sumdata$key = rownames(sumdata)
ggplot(data=sumdata, aes(x=key, y = value, fill=key)) +
  geom_bar(color='black', stat='identity')+
  labs(title = 'Total Distance by Activity Level', x='Activity Level', y='Distance')

Sum_Very_Active <- daily_activity %>% group_by(Id) %>%
  drop_na() %>%
  summarize(sum_very_active_time = sum(VeryActiveMinutes))

Sum_Mod_Active <- daily_activity %>% group_by(Id) %>%
  drop_na() %>%
  summarize(sum_mod_active_time = sum(FairlyActiveMinutes))

Sum_Light_Active <- daily_activity %>% group_by(Id) %>%
  drop_na() %>%
  summarize(sum_light_active_time = sum(LightlyActiveMinutes))

Summary_Chart_temp_1 <- merge(Sum_Very_Active, Sum_Mod_Active, by=("Id"))
Summary_Chart_Time <- merge(Summary_Chart_temp, Sum_Light_Active, by="Id")
barplot_data_time <- Summary_Chart_Time[c(-1)]
sumdata_time = data.frame(value=apply(barplot_data_time,2,sum))
sumdata_time$key = rownames(sumdata)
ggplot(data=sumdata_time, aes(x=key, y = value, fill=key)) +
  geom_bar(color='black', stat='identity')+
  labs(title = 'Total Time by Activity Level', x='Activity Level', y='Minutes')

ggplot(daily_activity)+
  geom_point(mapping=aes(x=VeryActiveDistance, y=VeryActiveMinutes, color = TotalSteps)) +
  geom_smooth(method = 'lm', mapping=aes(x=VeryActiveDistance, y=VeryActiveMinutes)) +
  labs(title = 'Distance vs Time Very Active', x='Distance in Miles', y='Minutes')
